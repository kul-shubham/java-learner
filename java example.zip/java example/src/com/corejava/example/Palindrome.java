package com.corejava.example;

public class Palindrome {

	public static void main(String[] args) {
		
		int num = 34543;
	
		int rev = 0;
		
		while(num!=0) {
			rev = rev*10 + num%10;
			num = num / 10;
		}
		if(rev==num) {
			System.out.println(rev+" is palindrome number");
		}else {
			System.out.println(rev+" is not palindrome number");
		}
		
		
		

	}

}
