package com.corejava.example;

public class AccesingEle {

	public static void main(String[] args) {
		int in = 4739 ;
		// by stringBuffer method
//		StringBuffer sb = new StringBuffer(ss);
//		StringBuffer rev = sb.reverse();
//		System.out.println("Reversed string is "+ rev);

//		// by char array
		int rev = 0;
		
////		char[] a = ss.toCharArray();
//		for(int i = a.length-1;i>=0;i--) {
//			rev+=a[i];
		for(int i = in-1;i>=0;i--) {
			rev+=i;
		}
		System.out.println(rev);
	}
		
		
		
		
		
		}
//		
		
	


